﻿using Assignment.Model;
using Assignment.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly ILogger<TodoController> _logger;
        private readonly IUserService _authservice;
        public AuthController(IUserService authservice)
        {
            _authservice = authservice;
        }


        [HttpPost("adminregistration")]
        public User AdminRegistration(User model)
        {
            model.Roles = "Admin";
            return _authservice.RegistrationUser(model);
        }

        [HttpPost("userregistration")]
        [AllowAnonymous]
        public User UserRegistration(User model) 
        {
            model.Roles = "User";
            return _authservice.RegistrationUser(model);
        }

        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Authenticate([FromBody] AuthenticateRequest model)
        {           
            var response = await _authservice.Authenticate(model);

            //if (response == null)
            //    return BadRequest(new ApiErrorResponse { Message = "Username or password is incorrect" });

            //setTokenCookie(response.RefreshToken);

            return Ok(response);
        }
    }
}
