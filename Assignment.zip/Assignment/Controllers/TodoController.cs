﻿using Assignment.Model;
using Assignment.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Assignment.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TodoController : ControllerBase
    {
        private readonly ILogger<TodoController> _logger;
        private readonly ITodoService _todoservice;
        public TodoController(ITodoService todoservice)
        {
            _todoservice= todoservice;
        }

       
        [HttpGet("Get")]
        [Authorize]
        public async Task<IEnumerable<Todo>> Get()
        {

            return await _todoservice.GetAll();
        }
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Get(int id)
        {
            var userName = User.FindFirstValue(ClaimTypes.Role);
            if (userName != "Admin")
            {
                return Unauthorized();
            }
            return Ok(await _todoservice.GetById(id));
        }
        [HttpPut]
        [Authorize]

        public IActionResult Update(Todo model)
        {
            var userName = User.FindFirstValue(ClaimTypes.Role);
            if (userName != "Admin")
            {
                return Unauthorized();
            }
            return Ok(_todoservice.Update(model));
        }

     
        [HttpDelete]
        [Authorize]

        public async Task<IActionResult> Update(int id)
        {
            var userName = User.FindFirstValue(ClaimTypes.Role);
            if (userName != "Admin")
            {
                return Unauthorized();
            }
            Todo model = await _todoservice.GetById(id);
            _todoservice.Delete(model);
            return Ok();
        }
    }
}
