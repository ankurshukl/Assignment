﻿using Assignment.Model;
using Assignment.Utility;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Assignment.Service
{
    public class TokenManagerService : ITokenManagerService
    {
        private readonly IDistributedCache _cache;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IOptions<AppSettings> _jwtOptions;
        private readonly AppSettings _appSettings;

        public TokenManagerService(IDistributedCache cache,
                IHttpContextAccessor httpContextAccessor,
                IOptions<AppSettings> jwtOptions,
                IOptions<AppSettings> appSettings
            )
        {
            _cache = cache;
            _httpContextAccessor = httpContextAccessor;
            _jwtOptions = jwtOptions;
            _appSettings = appSettings.Value;
        }

        public async Task<bool> IsCurrentActiveToken()
            => await IsActiveAsync(GetCurrentAsync());

        public async Task DeactivateCurrentAsync()
            => await DeactivateAsync(GetCurrentAsync());

        public async Task<bool> IsActiveAsync(string token)
            => await _cache.GetStringAsync(GetKey(token)) == null;

        public async Task DeactivateAsync(string token)
            => await _cache.SetStringAsync(GetKey(token),
                " ", new DistributedCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow =
                        //TimeSpan.FromMinutes(_jwtOptions.Value.ExpiryMinutes)
                        TimeSpan.FromDays(10)
                });

        public string generateJwtToken(User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.secret);
            var claims = new List<Claim>();

            claims.Add(new Claim(ClaimTypes.Name, Convert.ToString(user.UserId)));
            claims.Add(new Claim("FirstName", Convert.ToString(user.FirstName) + " " + Convert.ToString(user.LastName)));
            claims.Add(new Claim("LastName", Convert.ToString(user.LastName)));
            claims.Add(new Claim("Email", Convert.ToString(user.Email)));
            claims.Add(new Claim("IsActive", Convert.ToString(user.IsActive)));
            claims.Add(new Claim(ClaimTypes.Role, user.Roles));

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims.ToArray()),
                Expires = DateTime.UtcNow.AddMinutes(60),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
        private string GetCurrentAsync()
        {
            var authorizationHeader = _httpContextAccessor
                .HttpContext.Request.Headers["authorization"];

            return authorizationHeader == StringValues.Empty
                ? string.Empty
                : authorizationHeader.Single().Split(" ").Last();
        }

        private static string GetKey(string token)
            => $"tokens:{token}:deactivated";
    }
}
