﻿using Assignment.Model;
using Assignment.Utility;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment.Service
{
    public class UserService : IUserService
    {
        private readonly DataContext _db;
        private readonly ITokenManagerService _tokenManager;

        public UserService(DataContext db, ITokenManagerService tokenManager, ILogger<UserService> logger)
        {
            _db = db;
            _tokenManager = tokenManager;
        }

        public async Task<AuthenticateResponse> Authenticate(AuthenticateRequest model)
        {

            User user = _db.Users.Where(x => x.Email == model.Email && x.Password == model.Password).FirstOrDefault();
            if (user == null) return null;
            var jwtToken = _tokenManager.generateJwtToken(user);
            return new AuthenticateResponse(user, jwtToken);
        }

        public User RegistrationUser(User model)
        {
            User user = new User();
            user.FirstName = model.FirstName;
            user.LastName = model.LastName;
            user.Email = model.Email;
            user.Roles = ERole.User;
            user.Password = model.Password;
            user.IsActive = true;
            _db.Users.Add(user);
            _db.SaveChanges();
            return user;
        }
        public User RegistrationAdmin(User model)
        {
            User user = new User();
            user.FirstName = model.FirstName;
            user.LastName = model.LastName;
            user.Email = model.Email;
            user.Roles = ERole.Admin;
            user.Password = model.Password;
            user.IsActive = model.IsActive;
            _db.Users.Add(user);
            _db.SaveChanges();
            return user;
        }
    }
}
