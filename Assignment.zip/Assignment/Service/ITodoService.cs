﻿using Assignment.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment.Service
{
    public interface ITodoService
    {
        Task<IEnumerable<Todo>> GetAll();
        Task<Todo> GetById(int Id);
        Todo Add(Todo model);
        Todo Update(Todo model);
        void Delete(Todo model);
    }
}
