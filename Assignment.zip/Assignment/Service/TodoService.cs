﻿using Assignment.Model;
using Assignment.Utility;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment.Service
{
    public class TodoService : ITodoService
    {
        private readonly DataContext _db;

        public TodoService(DataContext db)
        {
            _db = db;
        }


        public Todo Add(Todo model)
        {
            _db.Todos.Add(model);
            _db.SaveChanges();
            return model;
        }


        public void Delete(Todo model)
        {
            _db.Todos.Remove(model);
            _db.SaveChanges();
        }

        public async Task<IEnumerable<Todo>> GetAll()
        {
            return _db.Todos.ToList();
        }

        public async Task<Todo> GetById(int Id)
        {
            return _db.Todos.Where(x=> x.Id== Id).FirstOrDefault();
        }

        public Todo Update(Todo model)
        {
            _db.Todos.Update(model);
            _db.SaveChanges();
            return model;
        }
    }
}
