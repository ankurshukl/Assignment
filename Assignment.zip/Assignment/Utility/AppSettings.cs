﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment.Utility
{
    public class AppSettings
    {
        public string secret { get; set; }
        public string jwtIssuer { get; set; }
        public string jwtAudience { get; set; }
        public double expiryMinutes { get; set; }
    }
}
